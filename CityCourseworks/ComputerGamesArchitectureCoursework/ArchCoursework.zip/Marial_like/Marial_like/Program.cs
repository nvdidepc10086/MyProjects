﻿using MarialLike2D;

using var game = new MarialLikeGame();
game.Run();
